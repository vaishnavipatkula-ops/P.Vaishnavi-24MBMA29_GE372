# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS ecommerce;

# COMMAND ----------

from pyspark.sql.functions import trim

bronze_path = (
    "dbfs:/Volumes/workspace/default/e-commerce/bronze"
)
bronze_df = (
    spark.read.format("delta")
    .load(bronze_path)
)

bronze_df.write.mode("overwrite").saveAsTable("ecommerce.bronze_raw")

silver_df = (
    bronze_df
    .dropDuplicates()
    .na.drop(subset=["customer_id", "product_id", "quantity", "price"])
    .withColumn("customer_id", trim("customer_id"))
    .withColumn("product_id", trim("product_id"))
)

silver_df.write.mode("overwrite").saveAsTable("ecommerce.silver_clean")
display(silver_df)

# COMMAND ----------

print("silver pipeline completed successfully")
dbutils.notebook.exit("SUCCESS")
