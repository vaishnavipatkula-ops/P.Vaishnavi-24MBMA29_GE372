# Databricks notebook source
from pyspark.sql.functions import sum, count, col

silver_df = spark.table("ecommerce.silver_clean")

# 1. Purchase Prediction Base Table (Customer Purchase Frequency)
purchase_features = (
    silver_df
    .groupBy("customer_id")
    .agg(
        count("product_id").alias("TotalPurchases"),
        sum("quantity").alias("TotalQuantity"),
        sum(col("quantity") * col("price")).alias("TotalSpend")
    )
)
purchase_features.write.mode("overwrite").saveAsTable("ecommerce.gold_purchase_prediction")

# 2. Customer Segmentation (RFM)
rfm = (
    silver_df
    .groupBy("customer_id")
    .agg(
        count("num_orders").alias("Frequency"),
        sum("transaction_amount").alias("Monetary")
    )
)
rfm.write.mode("overwrite").saveAsTable("ecommerce.gold_customer_segmentation")

# 3. Product Recommendation (Product Co-Purchase Counts)
product_pairs = (
    silver_df
    .groupBy("customer_id", "product_id")
    .count()
)
product_pairs.write.mode("overwrite").saveAsTable("ecommerce.gold_product_recommendation")

# 4. Customer Lifetime Value (CLTV Approx)
cltv = purchase_features.withColumn("CLTV", col("TotalSpend") * 3)
cltv.write.mode("overwrite").saveAsTable("ecommerce.gold_cltv")

# 5. Churn Prediction Base Table
churn = purchase_features.withColumn("AvgOrderValue", col("TotalSpend") / col("TotalPurchases"))
churn.write.mode("overwrite").saveAsTable("ecommerce.gold_churn_prediction")

display(purchase_features)
display(rfm)
display(product_pairs)
display(cltv)
display(churn)

# COMMAND ----------

print("Gold pipeline completed successfully")
dbutils.notebook.exit("SUCCESS")