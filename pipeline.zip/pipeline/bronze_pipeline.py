# Databricks notebook source
# Load raw CSV into Bronze Layer (Raw Zone)
bronze_df = spark.read.csv(
    "dbfs:/Volumes/workspace/default/e-commerce/ecommerce_capstone_dataset_1000.csv",
    header=True,
    inferSchema=True
)

# Save as Delta file to a Unity Catalog volume
bronze_path = "dbfs:/Volumes/workspace/default/e-commerce/bronze"

bronze_df.write.format("delta").mode("overwrite").save(bronze_path)

print("✅ Bronze Layer created successfully at:", bronze_path)

# COMMAND ----------

print("bronze pipeline completed successfully")
dbutils.notebook.exit("SUCCESS")
