# Databricks notebook source
print("Starting Master Pipeline...")

# Run Bronze Pipeline
bronze_status = dbutils.notebook.run(
    "/Workspace/Users/vaishnavipatkula@gmail.com/pipeline/bronze_pipeline",
    timeout_seconds=300
)
print("Bronze Pipeline:", bronze_status)

if bronze_status != "SUCCESS":
    raise Exception("Bronze pipeline failed. Stopping execution.")


# Run Silver Pipeline
silver_status = dbutils.notebook.run(
    "/Workspace/Users/vaishnavipatkula@gmail.com/pipeline/silver_pipeline",
    timeout_seconds=300
)
print("Silver Pipeline:", silver_status)

if silver_status != "SUCCESS":
    raise Exception("Silver pipeline failed. Stopping execution.")


# Run Gold Pipeline
gold_status = dbutils.notebook.run(
    "/Workspace/Users/vaishnavipatkula@gmail.com/pipeline/gold_pipeline",
    timeout_seconds=300
)
print("Gold Pipeline:", gold_status)

if gold_status != "SUCCESS":
    raise Exception("Gold pipeline failed.")


print("Master Pipeline Completed Successfully.")
dbutils.notebook.exit("SUCCESS")
